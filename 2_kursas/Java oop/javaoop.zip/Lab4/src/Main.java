import button_hell.Groups;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        JFrame frame = new mainWindow("Studentų registracijos sistema");
    }
}