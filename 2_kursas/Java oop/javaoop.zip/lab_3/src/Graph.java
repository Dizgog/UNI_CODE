import javax.swing.*;

public class Graph extends JFrame {

    public Graph(String title, String[][] data){
        super(title);
        this.setSize(700, 600);
        this.setVisible(true);
    }

}
