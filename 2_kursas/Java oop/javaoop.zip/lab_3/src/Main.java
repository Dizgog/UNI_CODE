//Normantas Kuolas

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {

    public static void main(String[] args) {
        JFrame frame = new Skaiciuokle("Būsto paskolos skaičiuoklė");

    }
}