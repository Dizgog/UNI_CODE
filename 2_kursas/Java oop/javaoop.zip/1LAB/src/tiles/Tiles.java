package tiles;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;

public class Tiles {

    public BufferedImage image;
    public boolean collision = false;


}
