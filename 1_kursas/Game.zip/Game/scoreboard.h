void scoreboard(int score);
void Sort(int arr[]);
void print_board(int arr[]);
